<?php 
require_once('config/config.php');
include('class/class.main.php');
$data = json_decode(file_get_contents("php://input"));
	$id=$data->id;
	$field=$data->field;
	$table = $data->table;
	$res = $objmain->delete_data($id,$table,$field);

		if($res==1)
		{
			echo"Data Deleted";
		}
		else
		{
			echo "try again";
		}
?>