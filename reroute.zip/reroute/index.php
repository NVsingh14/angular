<!DOCTYPE html>
<html ng-app="myApp">
<head>
	<title>Angular</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="node_modules/angular/angular.min.js"></script>
	<script type="text/javascript" src="node_modules/angular-route/angular-route.min.js"></script>
  <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
  <script src="node_modules/ng-file-upload/dist/ng-file-upload-shim.min.js"></script> 
  <script src="node_modules/ng-file-upload/dist/ng-file-upload.min.js"></script>
	<script type="text/javascript" src="node_modules/app.js"></script>
	<script type="text/javascript" src="controller/routing.js"></script>
	<script type="text/javascript" src="controller/add_cat.js"></script>
	<script type="text/javascript" src="controller/add_sub_cat.js"></script>
  <script type="text/javascript" src="controller/product.js"></script>
  <script type="text/javascript" src="controller/list_cat.js"></script>
</head>
<body>
	<div class="container">
				<div class="row">
					<nav class="navbar navbar-inverse">
  						<div class="container-fluid">
    						<div class="navbar-header">
      							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
        					<span class="sr-only">Toggle navigation</span>
        				<span class="icon-bar"></span>
        		<span class="icon-bar"></span>
        	<span class="icon-bar"></span>
      	</button>
      							<a class="navbar-brand" href="#">App Demo</a>
    						</div>  						
    			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
      				<ul class="nav navbar-nav">
        				<li><a href="#/catAdd">Category Add</a></li>
                <li><a href="#/catList">Category List</a></li>
        				<li><a href="#/subcatAdd">Sub Category</a></li>
                <li><a href="#/prodAdd">Add Product</a></li>
      				</ul>
    			</div>
  						</div>
					</nav>
				</div>

					<div class="jumbotron" ng-view="">
					</div>
		</div> <!-- end of container -->
</body>
</html>