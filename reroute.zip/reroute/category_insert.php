<?php 
require_once('config/config.php');
include_once('class/class.main.php');
$data = json_decode(file_get_contents("php://input"));
//print_r($data);
$cat_name=$data->data->cat_name;
$meta_title = $data->data->meta_title;
$keyword = $data->data->keyword;
$description = $data->data->description;
$slug= $data->data->slug;
	
	$res = $objmain->category_add($cat_name,$meta_title,$keyword,$description,$slug);


if($res==1)
{
	echo "data inserted";
}
else
{
	echo "try again";
}

?>