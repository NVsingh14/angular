<?php 
require_once('config/config.php');
include_once('class/class.main.php');
$data = json_decode(file_get_contents("php://input"));
$prd_name = $data->data->prd_name;
$item_code=$data->data->item_code;
$description = $data->data->editor1;
$prd_price = $data->data->prd_price;
$discount = $data->data->discount_val;
$slug= $data->data->slug;
$img =$data->data->img_hidden;

	 $res = $objmain->product_add($prd_name,$item_code,$description,$prd_price,$discount,$slug,$img);
     if($res==1)
     {
         echo"inserted";
     }
     else
     {
         echo"try";
     }
?>