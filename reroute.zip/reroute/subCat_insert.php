<?php 
require_once('config/config.php');
include_once('class/class.main.php');
$data = json_decode(file_get_contents("php://input"));

$cat_id = $data->data->cat_name;
$sub_cat = $data->data->sub_cat_name;
$meta_title = $data->data->meta_title;
$keyword = $data->data->keyword;
$description = $data->data->description;
$slug = $data->data->slug;

$res = $objmain->sub_category_add($cat_id,$sub_cat,$meta_title,$keyword,$description,$slug);
if($res==1)
{
	echo"data inserted succcessfully";
}
else
{
	echo"try agin";
}


?>