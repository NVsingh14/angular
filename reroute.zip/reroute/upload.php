<?php 
if(!empty($_FILES)){
	//echo $_FILES['file']['name'];
	$tmpPath = $_FILES['file']['tmp_name'];
	$uploadPath = 'image/'.$_FILES['file']['name'];
	if(move_uploaded_file($tmpPath,$uploadPath))
	{
		$returnArr = array('SUCCESS'=>1,'MSG'=>'File Is Uploaded','PATH_TO_IMAGE'=>$uploadPath,'IMAGE_NAME'=>$_FILES['file']['name']);
	}
	else
	{
	$returnArr = array('SUCCESS'=>0,'MSG'=>'Unable To Upload','PATH_TO_IMAGE'=>'','IMAGE_NAME'=>'');
	}
	

}
else
	{
		$returnArr = array('SUCCESS'=>3,'MSG'=>'Unable To Upload','PATH_TO_IMAGE'=>'','IMAGE_NAME'=>'');
	}
$json = json_encode($returnArr);
echo $json;
?>