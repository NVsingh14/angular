
	app.controller('cat_listCtrl',['$scope','$http','$timeout','$window',function($scope,$http,$timeout,$window){
		$http.get('fetch_subcategory.php').
				then(function(resp){
					console.log(resp);
					$scope.result = resp.data;
				})


		$scope.delete_category = function(did)
		{
			var c = confirm("Are You Sure To Delete This Item ?");
			if(c)
			{
				$http.post('delete.php',{id:did,table:'category',field:'cat_id'}).then(function(response){
					//console.log(response);
					$scope.msg = true;
					$scope.msgData = "Data Deleted Successfully";
					$timeout(function(){
						$scope.msg=false;
						$window.location.reload();
					},3000)
				});
			}
			else
			{
				return false;
			}
		}
	}]); //end of controller