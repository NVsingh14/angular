	
	app.config(['$routeProvider', function($routeProvider){

		$routeProvider
						.when('/welcome',{
							title:'Welcome',
							templateUrl:'welcome.html',
							controller:'welcomeCtrl'
						})
						.when('/catAdd',{
							title:'Add Category',
							templateUrl:'category.html',
							controller:'catCtrl'
						})
						.when('/catList',{
							title:'category list',
							templateUrl:'category-list.html',
							controller:'cat_listCtrl'
						})
						.when('/catAdd/:id',{
							templateUrl:'category.html',
							controller:'catCtrl'
						})
						.when('/subcatAdd',{
							title:'Add Subcategory',
							templateUrl:'subcategory.html',
							controller:'subcatCtrl'
						})
						.when('/prodAdd',{
							title:'Add Product',
							templateUrl:'product.html',
							controller:'prodCtrl'
						})
						.otherwise({
							redirectTo: 'welcome'
						});
	
	}]); //end of config