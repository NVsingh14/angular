
	app.controller('subcatCtrl',['$scope','$http','$timeout',function($scope,$http,$timeout){

		$http.get('fetch_subcategory.php').then(function(response){
			$scope.result = response.data;
		});
		$scope.dataFrm = {
			cat_name:'',
			sub_cat_name:'',
			meta_title:'',
			keyword:'',
			description:'',
			slug:''
		};
		$scope.sub_category_insert = function()
		{
			$http.post('subCat_insert.php',{data:$scope.dataFrm}).
					then(function(response){
						//alert("response");
						//console.log(response);
						$scope.dataFrm=null;
						$scope.msg=true;
						$scope.msgData="Data Inserted Successfully";
						$timeout(function(){
							$scope.msg=false;
						},3000)

					})
		}

	}]); //end of controller