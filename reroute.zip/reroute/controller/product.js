
	app.directive('ckEditor',function() {
		return {
			require:'?ngModel',
			link:function(scope,elm, attr, ngModel) {
				var ck = CKEDITOR.replace(elm[0]);

				if(!ngModel) return;

				ck.on('pasteState',function() {
					scope.$apply(function() {
						ngModel.$setViewValue(ck.getData());
					});
				});

				ngModel.$render = function (value) {
					ck.setData(ngModel.$viewValue);
				};
			}
		};
	}); //end of directive

	app.controller('prodCtrl',['$scope','$http','$timeout','Upload',function($scope,$http,$timeout,Upload){
		$scope.dataFrm = {
			prd_name:'',
			item_code:'',
			editor1:'',
			prd_price:'',
			discount_val:'',
			slug:'',
			img_hidden:''
		};

$scope.prd_sub = function()
{
	//console.log($scope.dataFrm);
	$http.post('product_insert.php',{data:$scope.dataFrm}).
	then(function(resp){
		//alert("data");
		//console.log(resp);
		$scope.dataFrm=null;
		$scope.msg=true;
		$scope.msgData="Data inserted Succsfully";
		$timeout(function(){
			$scope.msg=false;
		},3000)
	})

}
		$scope.fuploading = 0;
	$scope.upload = function(file) {
	//alert("enter");
	console.log(file);
	Upload.upload({
		url:'upload.php',
		data:{file:file}
	}).then(function (resp) {
		//alert("rest");
		console.log(resp);
		if(resp.data.SUCCESS=="1")
		{
			$scope.dataFrm.img_hidden = resp.data.IMAGE_NAME;
			$scope.dataFrm.news_image_disp = resp.data.PATH_TO_IMAGE;
			$scope.fuploading=2;
		}
		else
		{
			$scope.fileuploaderror = resp.data.MSG;
			$scope.fuploading=3;
			$timeout(function(){
				$scope.fuploading=0;
			},3000);
		}
	})

} //end of upload function

		$scope.removeImage = function()
		{
			var c =confirm("Are You Sure you wish to Delete?");
			if(c)
			{
				 $scope.fuploading = 0;
                $scope.dataFrm.img_hidden = '';  
                $scope.dataFrm.news_image_disp = '';  
            }
			
		}//end of remove image function

	}]); //end of controller